//
//  NewViewController.swift
//  Fulhaal Patrans
//
//  Created by Sachin on 30/10/21.
//

import UIKit
import Alamofire
class NewViewController: UIViewController {
    // MARK: - Properties
    @IBOutlet weak var tableView: UITableView! {
        didSet {
            self.tableView.delegate = self
            self.tableView.dataSource = self
        }
    }
    @IBOutlet weak var txtFieldToTime: UITextField!
    @IBOutlet weak var txtFieldToDate: UITextField!
    @IBOutlet weak var txtFielfFormTime: UITextField!
    @IBOutlet weak var txtFieldSearch: UITextField!
    @IBOutlet weak var txtFieldForm: UITextField!
    @IBOutlet weak var bgFormTimeView: UIView!
    @IBOutlet weak var bgToTimeView: UIView!
    @IBOutlet weak var bgViewTo: UIView!
    @IBOutlet weak var bgViewForm: UIView!
    @IBOutlet weak var bgViewSearch: UIView!
    @IBOutlet weak var btnSubmit: UIButton!
    // MARK: - Variables
    var datePicker = UIDatePicker()
    var timePicker = UIDatePicker()
    var searchedResult = ["HPI23123", "GHG23321", "KL232312", "OPO23123", "WE#2312"]
    // MARK: - Life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setBorderAndRadius(views: [self.bgViewSearch, self.bgViewForm, self.bgViewTo, self.bgFormTimeView, self.bgToTimeView, self.btnSubmit])
        self.datePicker.datePickerMode = .date
        if #available(iOS 13.4, *) {
            self.datePicker.preferredDatePickerStyle = .wheels
            self.timePicker.preferredDatePickerStyle = .wheels

        } else {
            // Fallback on earlier versions
        }
        self.timePicker.datePickerMode = .time
        self.txtFieldForm.inputView = self.datePicker
        self.txtFieldToDate.inputView = self.datePicker
        self.txtFielfFormTime.inputView = self.timePicker
        self.txtFieldToTime.inputView = self.timePicker
        self.txtFieldSearch.delegate = self
        self.txtFieldForm.delegate = self
        self.txtFieldToDate.delegate = self
        self.txtFielfFormTime.delegate = self
        self.txtFieldToTime.delegate = self
    }
    override func viewWillAppear(_ animated: Bool) {
        self.tableView.isHidden = true
        self.getVehicleList()
    }
    // MARK: - IBActions
    @IBAction func btnSubmit(_ sender: UIButton) {
    }
    // MARK: - Extra functions
    fileprivate func setBorderAndRadius(views: [UIView]) {
        for item in views {
            item.borderWidth = 1
            item.borderColor = .white
            item.cornerRadius = 15
        }
    }
    // MARK: - APIs
    func getVehicleList() {
        AF.request(URL.init(string: "https://trackingexperts.com/appv11/alllistsearchv3.php")!, method: .post, parameters: nil, encoding: JSONEncoding.default, headers: .init(["KAISAPAISA": "APIapiGTRACgtrac"])).responseData(completionHandler: { response in
            switch response.result {
            case .success(let res):
                if let code = response.response?.statusCode {
                    switch code {
                    case 200...299:
                        do {
                           let responseData = try JSONDecoder().decode(GetVehicleList.self, from: res)
                            print(responseData)
                        } catch let error {
                            print(String(data: res, encoding: .utf8) ?? "nothing received")
                            print(error.localizedDescription)

                        }
                    case 403, 401, 400, 404, 409, 500, 502, 503, 504, 522, 422:
                        print( response.data ?? Data())
                    default:
                        print( response.data ?? Data())
                    }
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        })
    }
    
}
// MARK: - Extension UI
extension NewViewController: UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.txtFieldForm {
            self.txtFieldForm.text = "\(self.datePicker.date)"
        } else if textField == self.txtFieldToDate {
            self.txtFieldToDate.text = "\(self.datePicker.date)"
        } else if textField == self.txtFielfFormTime {
            self.txtFielfFormTime.text = "\(self.timePicker.date)"
        } else if textField == self.txtFieldToTime {
            self.txtFieldToTime.text = "\(self.timePicker.date)"
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == self.txtFieldSearch {
            if string.count >= 1 {
                self.tableView.isHidden = false
            } else {
                self.tableView.isHidden = true
            }
            return true
        } else {
            return true
        }
    }
}
extension NewViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.searchedResult.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "Cell")
          cell.textLabel?.text = self.searchedResult[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let nextVc = UIStoryboard.init(name: "New", bundle: nil).instantiateViewController(withIdentifier: "ReportsDetailsViewController") as? ReportsDetailsViewController else { return }
                   self.navigationController?.pushViewController(nextVc, animated: true)
        self.tableView.isHidden = true
    }
}
struct GetVehicleList: Codable {
    var status: Int?
}
