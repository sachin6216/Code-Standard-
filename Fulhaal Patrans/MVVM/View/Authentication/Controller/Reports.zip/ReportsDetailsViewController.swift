//
//  ReportsDetailsViewController.swift
//  Fulhaal Patrans
//
//  Created by Sachin on 31/10/21.
//

import UIKit
class ReportsDetailsUITableViewCell: UITableViewCell {
    @IBOutlet weak var lblTemp: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblDis: UILabel!
    @IBOutlet weak var lblOdeMeter: UILabel!
    @IBOutlet weak var lblSpeed: UILabel!
    @IBOutlet weak var lblAcOn: UILabel!
    @IBOutlet weak var lblAcOff: UILabel!
    @IBOutlet weak var lblNum: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    override func awakeFromNib() {
        
    }
}
class ReportsDetailsViewController: UIViewController {
    // MARK: - Properties
    @IBOutlet weak var tableView: UITableView! {
        didSet {
            self.tableView.delegate = self
            self.tableView.dataSource = self
        }
    }
    // MARK: - Variables
    enum SelectScreenFor {
        case temp
        case acReport
    }
    var selectedScreenFor: SelectScreenFor = .temp
    // MARK: - Life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
    }
    // MARK: - IBActions
    // MARK: - Extra functions
    // MARK: - APIs
    
}
// MARK: - Extension UI
extension ReportsDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 15
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if self.selectedScreenFor == .temp {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tempCell", for: indexPath) as! ReportsDetailsUITableViewCell
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "acCell", for: indexPath) as! ReportsDetailsUITableViewCell
            return cell
        }
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
}
